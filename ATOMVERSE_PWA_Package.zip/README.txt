ATOMVERSE — PWA INSTALL PACKAGE

FILES
- index.html: your ATOMVERSE app
- manifest.webmanifest: install name, display settings and icon references
- sw.js: offline app-shell cache
- icons/: home-screen icons

IMPORTANT
A Progressive Web App must be hosted on an HTTPS website (or localhost) for Chrome to install it.
Opening index.html directly from Downloads/file:// will not show the Install app option.

EASY DEPLOYMENT
1. Upload the contents of this folder to a static website host that gives you an HTTPS address.
   Keep the folder structure exactly as it is.
2. Open the HTTPS website address in Google Chrome on your Android phone.
3. Open Chrome's ⋮ menu and choose "Install app" or "Add to Home screen".
4. Confirm. ATOMVERSE should appear as an app icon.

You can use a static host such as GitHub Pages or Netlify. Account setup and publishing may require help from a parent/guardian.
This package is a PWA, not a Play Store APK/AAB. It does not publish anything to Google Play.

If you update the app later, change CACHE_NAME in sw.js (for example atomverse-v2) so the browser refreshes its offline cache.
